package com.dating.user;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FindMatchImpl implements FindMatch {
	
	
	@Override
	public User getContextUserExist(String userName) {
		Map<String, User> allUsers = TestUsersData.getUsers();
		User ctxUser = allUsers.get(userName);
		return ctxUser;
	}
	@Override
	public List<User> findMatches(String userName) {
		Map<String, User> allUsers = TestUsersData.getUsers();
		User ctxUser = getContextUserExist(userName);
		if(ctxUser == null)
			System.out.println("Request user does not exist");
		
		ContextualComparator comp = new ContextualComparator(ctxUser);
		List<User> usersList = allUsers.entrySet().stream().filter(r->! r.getKey().equals(userName)).map(r->r.getValue()).collect(Collectors.toList());
		Collections.sort(usersList, comp);
		
		return usersList.subList(0, 2);
	}

}
