package com.dating.user;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class TestDatingApp {

	public static void main(String[] args) {
		Map<String, User> allUsers = TestUsersData.getUsers();
		User ctxUser = allUsers.get("UserB");
		System.out.println("ctx user:" + ctxUser);
		ContextualComparator comp = new ContextualComparator(ctxUser);
		List<User> usersList = allUsers.entrySet().stream().filter(r->! r.getKey().equals("UserB")).map(r->r.getValue()).collect(Collectors.toList());
		
		Collections.sort(usersList, comp);
		System.out.println("sorted users:");
		for(User user: usersList) {
		System.out.println(user.toString());
		}
	}

}
