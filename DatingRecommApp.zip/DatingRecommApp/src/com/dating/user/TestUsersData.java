package com.dating.user;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TestUsersData {
	private static Map<String, User> usersMap = null;

	public static Map<String, User> getUsers() {
		
		usersMap = new HashMap<String, User>();
		User user1 = new User();
		user1.setName("UserA");
		user1.setGender("Female");
		user1.setAge(25);
		List<String> interest = new ArrayList<String>();
		interest.add("Cricket");
		user1.setInterests(interest);
		usersMap.put("UserA", user1);
		
		User user2 = new User();
		user2.setName("UserB");
		user2.setGender("Male");
		user2.setAge(27);
		List<String> interest2 = new ArrayList<String>();
		interest2.add("Cricket");
		interest2.add("Football");
		interest2.add("Movies");
		user2.setInterests(interest2);
		usersMap.put("UserB", user2);
		
		User user3 = new User();
		user3.setName("UserC");
		user3.setGender("Male");
		user3.setAge(26);
		List<String> interest3 = new ArrayList<String>();
		interest3.add("Movies");
		interest3.add("Tennis");
		interest3.add("Football");
		interest3.add("Cricket");
		user3.setInterests(interest3);
		usersMap.put("UserC", user3);		
		
		User user4 = new User();
		user4.setName("UserD");
		user4.setGender("Female");
		user4.setAge(24);
		List<String> interest4 = new ArrayList<String>();
		interest4.add("Tennis");
		interest4.add("Football");
		interest4.add("Badminton");
		user4.setInterests(interest4);
		usersMap.put("UserD", user4);		
		
		User user5 = new User();
		user5.setName("UserE");
		user5.setGender("Female");
		user5.setAge(32);
		List<String> interest5 = new ArrayList<String>();
		interest5.add("Cricket");
		interest5.add("Football");
		interest5.add("Movies");
		interest5.add("Badminton");
		user5.setInterests(interest5);
		usersMap.put("UserE", user5);	
		
		return usersMap;
	}
}
