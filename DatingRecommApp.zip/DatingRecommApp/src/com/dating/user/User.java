package com.dating.user;

import java.util.List;

public class User {

	private String name;
	private String gender;
	private int age;
	private List<String> interests;
	

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<String> getInterests() {
		return interests;
	}
	public void setInterests(List<String> interests) {
		this.interests = interests;
	}
	
	@Override
	public String toString() {
		
		return "name-> " + name +" gender->" +gender + " age->"+age + " interestes->" + interests;
	}
	
}
