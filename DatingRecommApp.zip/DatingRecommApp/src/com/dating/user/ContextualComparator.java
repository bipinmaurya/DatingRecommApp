package com.dating.user;

import java.util.Comparator;
import java.util.List;

public class ContextualComparator implements Comparator<User> {
	private User ctxUser;
	
	public ContextualComparator(User user) {
		this.ctxUser = user;
	}
	
    @Override
    public int compare(User u1, User u2) {
        if(u1.getGender().equals(u2.getGender())){
        	
            int ageDiff = Math.abs(u1.getAge() - ctxUser.getAge());
            int ageDiff1 = Math.abs(u2.getAge() - ctxUser.getAge());
            System.out.println("");
            if(ageDiff > ageDiff1){
                return 1;
            }else if(ageDiff < ageDiff1){
                return  -1;
            }else{
                int commonPrefs = geCommonIterests(u1.getInterests(), ctxUser.getInterests());
                int commonPrefs1 = geCommonIterests(u2.getInterests(), ctxUser.getInterests());
                if(commonPrefs > commonPrefs1){
                    return -1;
                }else{
                    return 1;
                }
            }
        }else{
            if(u1.getGender().equals(ctxUser.getGender())){
                return 1;
            }else{
                return -1;
            }
        }
    }
    
    private int geCommonIterests(List<String> pref1, List<String> pref2 ) {
    	int count=0;
    	for(String pref: pref1) {
    		if(pref2.contains(pref)) {
    			count++;
    		}
    			
    	}
    	return count;
    }
}