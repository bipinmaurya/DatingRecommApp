package com.dating.user;

import java.util.List;

public interface FindMatch {

	public User getContextUserExist(String userName);
	public List<User> findMatches(String userName);
}
