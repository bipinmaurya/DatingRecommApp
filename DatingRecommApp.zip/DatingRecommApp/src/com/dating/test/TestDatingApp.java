package com.dating.test;

import java.util.List;

import org.junit.Test;

import com.dating.user.FindMatch;
import com.dating.user.FindMatchImpl;
import com.dating.user.User;

import junit.framework.TestCase;

public class TestDatingApp extends TestCase {
	protected FindMatch match = null;
	protected User ctxUser = null;
	@Override
	protected void setUp() throws Exception {
		match = new FindMatchImpl();
	}
	
	@Test
	public void testInvaliduser() {
		ctxUser = match.getContextUserExist("UserF");
		assertNull("User not found", ctxUser);
	}
	
	@Test
	public void testValiduser() {
		ctxUser = match.getContextUserExist("UserB");
		assertNotNull(ctxUser);
		assertEquals("UserB", ctxUser.getName());
	}
	
	@Test
	public void testTop2Matches() {
		List<User> top2Matches = match.findMatches("UserB");
		assertEquals("First value should be UserA", "UserA", top2Matches.get(0).getName());
		assertEquals("Second value should be UserC", "UserD", top2Matches.get(1).getName());
	}

}
